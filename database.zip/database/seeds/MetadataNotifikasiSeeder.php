<?php

use Illuminate\Database\Seeder;

class MetadataNotifikasiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('metadata')->where('metadata_module', '=', 'notifikasi')->delete();

        $notifikasi = [
	        ['user_id' => 1, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"1","setoran_qc":"1","laporan_qc":"1"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 2, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 3, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 4, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 5, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 6, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 7, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 8, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 9, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['user_id' => 10, 'metadata_module_id' => 0, 'metadata_module' => 'notifikasi', 'metadata_detail' => '{"rilisan":"0","proyek":"0","kategori":"0","setoran_edit":"0","setoran_qc":"1","laporan_qc":"0"}', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ];

        DB::table('metadata')->insert($notifikasi);
    }
}
