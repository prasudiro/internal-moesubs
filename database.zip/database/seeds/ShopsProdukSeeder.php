<?php

use Illuminate\Database\Seeder;

class ShopsProdukSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('shops')->delete();

        $product = [
	        ['shops_produk' => 'Gantungan Kunci', 'shops_detail' => 'PO Gantungan Kunci Logo Moesubs', 'shops_price' => 25000, 'shops_closed' => '2017-10-07 23:59:59'],
	        ];

        DB::table('shops')->insert($product);
    }
}
