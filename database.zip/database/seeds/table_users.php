<?php

use Illuminate\Database\Seeder;

class table_users extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->delete();

        $users = [
	        ['name' => 'Himeko', 'email' => 'prassaiyan@gmail.com', 'password' => bcrypt('jagonyangesub2017Himeko12345'), 'level' => 3, 'avatar' => 'https://c.disquscdn.com/uploads/users/4233/3179/avatar92.jpg?1495379871', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'iLuminarie', 'email' => 'symphoniaofdark@gmail.com', 'password' => bcrypt('jagonyangesub2017iLuminarie01'), 'level' => 2, 'avatar' => 'https://c.disquscdn.com/uploads/users/10710/1290/avatar92.jpg?1495380714', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'MozaikTM', 'email' => 'mozaik.tm@gmail.com', 'password' => bcrypt('jagonyangesub2017MozaikTM01'), 'level' => 2, 'avatar' => 'https://c.disquscdn.com/uploads/users/15739/2713/avatar92.jpg?1495228668', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'Otoy555', 'email' => 'Otoy555@plase.change.me', 'password' => bcrypt('jagonyangesub2017iOtoy55501'), 'level' => 2, 'avatar' => 'https://c.disquscdn.com/uploads/users/5599/8825/avatar92.jpg?1478335078', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'Duja', 'email' => 'Duja@plase.change.me', 'password' => bcrypt('jagonyangesub2017iDuja01'), 'level' => 2, 'avatar' => 'https://c.disquscdn.com/uploads/users/771/3575/avatar92.jpg?1408359321', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'irzie', 'email' => 'irvan.cys@gmail.com', 'password' => bcrypt('jagonyangesub2017irzie01'), 'level' => 2, 'avatar' => 'https://c.disquscdn.com/uploads/users/8121/4501/avatar92.jpg?1497346123', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
            ['name' => 'atsu', 'email' => 'atsu@please.change.me', 'password' => bcrypt('jagonyangesub2017atsu01'), 'level' => 2, 'avatar' => 'https://c.disquscdn.com/uploads/users/4236/4142/avatar92.jpg?1496657245', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
            ['name' => 'FarhanFA', 'email' => 'FarhanFA@please.change.me', 'password' => bcrypt('jagonyangesub2017FarhanFA01'), 'level' => 2, 'avatar' => 'https://c.disquscdn.com/uploads/users/11576/423/avatar92.jpg?1429466892', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
            ['name' => 'Neos', 'email' => 'Neos@please.change.me', 'password' => bcrypt('jagonyangesub2017Neos01'), 'level' => 2, 'avatar' => 'https://puu.sh/xr5oj.png', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
            ['name' => 'HB-chan', 'email' => 'HB-chan@please.change.me', 'password' => bcrypt('jagonyangesub2017HB-chan01'), 'level' => 2, 'avatar' => 'https://puu.sh/xr5jq.png', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
        ];

        DB::table('users')->insert($users);
    }
}
