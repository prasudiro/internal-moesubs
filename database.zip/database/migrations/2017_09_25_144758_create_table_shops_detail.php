<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableShopsDetail extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shops_detail', function (Blueprint $table) {
            $table->increments('shops_detail_id');
            $table->integer('shops_id');
            $table->integer('shops_detail_quantity');
            $table->string('shops_detail_buyer');
            $table->text('shops_detail_information');
            $table->integer('shops_detail_status')->comment('0 = Unpaid | 1 = Paid | 2 = Delivered');
            $table->enum('status', ['0', '1'])->comment('0 = Exists | 1 = Deleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shops_detail');
    }
}
