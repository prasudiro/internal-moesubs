<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableSetoran extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('setoran', function (Blueprint $table) {
            $table->increments('setoran_id');
            $table->string('setoran_name');
            $table->enum('setoran_type', ['0', '1'])->comment('0 = Edit | 1 = QC')->default(0);
            $table->integer('setoran_category');
            $table->integer('setoran_episode');
            $table->integer('setoran_media')->comment('0 = TV | 1 = Movie | 2 = OVA/OAD | 3 = SP')->default(0);
            $table->string('setoran_file');
            $table->enum('status', ['0', '1'])->comment('0 = Exists | 1 = Deleted')->default(0);
            $table->integer('user_id')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('setoran');
    }
}
