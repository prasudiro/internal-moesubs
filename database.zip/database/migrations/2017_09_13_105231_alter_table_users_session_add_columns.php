<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterTableUsersSessionAddColumns extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users_sessions', function(Blueprint $table){
            $table->text('users_sessions_module')->nullable()->after('users_sessions_detail');
            $table->text('users_sessions_action')->nullable()->after('users_sessions_module');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users_sessions', function(Blueprint $table){
          $table->dropColumn('users_sessions_module');
        });
    }
}
