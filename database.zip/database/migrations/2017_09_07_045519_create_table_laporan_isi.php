<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableLaporanIsi extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('laporan_isi', function (Blueprint $table) {
            $table->increments('laporan_isi_id');
            $table->integer('laporan_id');
            $table->text('laporan_isi_detail');
            $table->integer('user_id')->default(1);
            $table->enum('status', ['0', '1'])->comment('0 = Exists | 1 = Deleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('laporan_isi');
    }
}
