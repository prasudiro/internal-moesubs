<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterTableLaporanAddStatus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('laporan', function(Blueprint $table){
            $table->enum('status', ['0', '1'])->comment('0 = Exists | 1 = Deleted')->default(0)->after('laporan_media');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('laporan', function(Blueprint $table){
          $table->dropColumn('status');
        });
    }
}
