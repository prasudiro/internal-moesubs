default
<p>
	<a href="<?php echo e(URL('logout')); ?>">logout</a>
</p>