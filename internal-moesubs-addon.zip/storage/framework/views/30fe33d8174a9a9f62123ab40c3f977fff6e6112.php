<?php

echo trans('Report::example.welcome');