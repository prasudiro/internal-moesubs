<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Portal Internal | [Moesubs] Jagonya Ngesub</title>

    <link href="<?php echo e(URL('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(URL('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('css/style.css')); ?>" rel="stylesheet">

    <link rel="shortcut icon" type="image/icon" href="https://puu.sh/wbdmk.png" width="64">

</head>

<body class="gray-bg">

    <div class="loginColumns animated fadeInDown">
<center>
<?php if(Session::has('error_msg')): ?>
    <div class="alert alert-danger"><h5><?php echo Session::get('error_msg'); ?></h5></div>
<?php elseif(Session::has('success_msg')): ?>
    <div class="alert alert-success"><h5><?php echo Session::get('success_msg'); ?></h5></div>
<?php endif; ?>
</center>
        <div class="row">

            <div class="col-md-6">
                <h2 class="font-bold text-cen">
                    <a href="<?php echo e(URL('/')); ?>" title="[Moesubs] Jagonya Ngesub"><img src="<?php echo e(URL('img/logo/Moev2.png')); ?>" alt="[Moesubs] Jagonya Ngesub" width="300"></a>
                </h2>


            </div>
            <div class="col-md-6">
                <div class="ibox-content">
                    <h3><b>Halo, Produser!</b></h3>
                    <p>Bisa tunjukkan SIM dan STNK-nya?</p>
                    <form class="m-t" role="form" method="post" action="<?php echo e(URL('login')); ?>" accept-charset="utf-8">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <input type="name" class="form-control" placeholder="SIM" name="name" required="">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="STNK" name="password" required="">
                        </div>
                        <button type="submit" class="btn btn-danger block full-width m-b">Masuk</button>

                        <a href="#">
                            <small>Lupa SIM dan STNK?</small>
                        </a>
                    </form>
                </div>
            </div>
        </div>
        <div class="row text-center">
            <p class="m-t">
                <small>[Moesubs] Jagonya Ngesub &copy; 2010-<?php echo e(date('Y')); ?></small>
            </p>
        </div>
    </div>

</body>

</html>
