<?php

use Illuminate\Database\Seeder;

class table_users extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->delete();

        $users = [
	        ['name' => 'Himeko', 'email' => 'prassaiyan@gmail.com', 'password' => bcrypt('jagonyangesub2017Himeko12345'), 'level' => 3, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'iLuminarie', 'email' => 'symphoniaofdark@gmail.com', 'password' => bcrypt('jagonyangesub2017iLuminarie01'), 'level' => 2, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'MozaikTM', 'email' => 'mozaik.tm@gmail.com', 'password' => bcrypt('jagonyangesub2017iMozaikTM01'), 'level' => 2, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'Otoy555', 'email' => 'Otoy555@plase.change.me', 'password' => bcrypt('jagonyangesub2017iOtoy55501'), 'level' => 2, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'Duja', 'email' => 'Duja@plase.change.me', 'password' => bcrypt('jagonyangesub2017iDuja01'), 'level' => 2, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
	        ['name' => 'irzie', 'email' => 'irvan.cys@gmail.com', 'password' => bcrypt('jagonyangesub2017irzie01'), 'level' => 2, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
            ['name' => 'atsu', 'email' => 'atsu@please.change.me', 'password' => bcrypt('jagonyangesub2017atsu01'), 'level' => 2, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
            ['name' => 'neos', 'email' => 'neos@please.change.me', 'password' => bcrypt('jagonyangesub2017neos01'), 'level' => 2, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
            ['name' => 'HB-chan', 'email' => 'HB-chan@please.change.me', 'password' => bcrypt('jagonyangesub2017HB-chan01'), 'level' => 2, 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")],
        ];

        DB::table('users')->insert($users);
    }
}
