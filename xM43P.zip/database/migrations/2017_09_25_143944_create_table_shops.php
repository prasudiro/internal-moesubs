<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableShops extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shops', function (Blueprint $table) {
            $table->increments('shops_id');
            $table->string('shops_product');
            $table->text('shops_detail');
            $table->decimal('shops_price', 10, 2);
            $table->integer('shops_discount')->comment('0 = Normal Price | 1 = Discount')->default(0);
            $table->decimal('shops_discount_percent')->default(0);
            $table->integer('shops_status')->comment('0 = PO | 1 = Ready Stok')->default(0);
            $table->dateTime('shops_closed');
            $table->integer('user_id')->default(1);
            $table->enum('status', ['0', '1'])->comment('0 = Exists | 1 = Deleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shops');
    }
}
